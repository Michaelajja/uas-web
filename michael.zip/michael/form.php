<?php
include "kon.php";

if(isset($_POST['submit'])){
  $nama = $_POST['nama'];
  $jurusan = $_POST['jurusan'];
  $email = $_POST['email'];
  $password = $_POST['password'];
  $jeniskelamin = $_POST['jeniskelamin'];
  $lahir = $_POST['lahir'];
  $alamat = $_POST['alamat'];


  if ($nama && $jurusan && $email && $password && $jeniskelamin && $lahir && $alamat) {
    $sql1 = "insert into data (nama, jurusan, email, password, jeniskelamin, lahir, alamat) values ('$nama','$jurusan','$email','$password','$jeniskelamin','$lahir','$alamat')";
    $q1 = mysqli_query($koneksi,$sql1);
  
  } 
  
echo "data berhasil";

}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Formulir</title>
    <link rel="stylesheet" href="style.css">
   </head>
<body>

  

  <div class="formbold-main-wrapper">
    <div class="formbold-form-wrapper">
    
  <div class="container">
      <form action="" method="POST">
        <div class="formbold-form-title">
          <h2 style="text-align: center; font-weight: bolder" class="">Data Mahasiswa Baru</h2>
        </div>

        <div class="formbold-mb-3">
            <label for="address2" class="formbold-form-label">
            </label>
            <input
            placeholder="Nama"
              type="text"
              name="nama"
              id="nama"
              class="formbold-form-input"
            />
          </div>
  
        <div class="formbold-mb-3">
            <label for="address2" class="formbold-form-label">
            </label>
            <input
            placeholder="Jurusan"
              type="text"
              name="jurusan"
              id="jurusan"
              class="formbold-form-input"
            />
          </div>
  
        <div class="formbold-mb-3">
            <label for="address2" class="formbold-form-label">
            </label>
            <input
            placeholder="Email"
              type="text"
              name="email"
              id="email"
              class="formbold-form-input"
            />
          </div>

        <div class="formbold-mb-3">
            <label for="address2" class="formbold-form-label">
            </label>
            <input
            placeholder="Password"
              type="text"
              name="password"
              id="password"
              class="formbold-form-input"
            />
          </div>

          <div class="formbold-mb-3">
            <label for="address" class="formbold-form-label">
            </label>
            <input
            placeholder="Jenis Kelamin"
              type="text"
              name="jeniskelamin"
              id="jeniskelamin"
              class="formbold-form-input"
            />
          </div>
  
        <div class="formbold-mb-3">
          <label for="address" class="formbold-form-label">
          </label>
          <input
          placeholder="Tanggal Lahir"
            type="text"
            name="lahir"
            id="lahir"
            class="formbold-form-input"
          />
        </div>
  
        <div class="formbold-mb-3">
          <label for="address2" class="formbold-form-label">
          </label>
          <input
          placeholder="Alamat"
            type="text"
            name="alamat"
            id="alamat"
            class="formbold-form-input"
          />
        </div>
        <button style="position: relative; left: 0%; width: 100%;" class="formbold-btn" name="submit" id="submit">Kirim Data</button>
      </form>
    </div>
    </div>
  </div>

  
  </body>

</html>