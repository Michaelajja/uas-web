<?php
include "kon.php";
?>

<!DOCTYPE html>

<html>

<head>

 <title>Table layout</title>

 <link rel="stylesheet" href="styl.css">

</head>

<body>


  <div class="filter">

 </div>

 <table >
    <thead>
        <tr>
    <th>Name</th>
    <th>Jurusan</th>
    <th>Email</th>
    <th>Password</th>
    <th>Jenis Kelamin</th>
    <th>Tanggal Lahir</th>
    <th>Alamat</th>
</tr>
</thead>
<tbody>

    <?php
          $sql2 = "select * from data order by 'id' desc";
          $q2 = mysqli_query($koneksi,$sql2);
          while($r2 = mysqli_fetch_array ($q2)){
            $nama = $r2['nama'];
            $jurusan = $r2['jurusan'];
            $email = $r2['email'];
            $password = $r2['password'];
            $jeniskelamin = $r2['jeniskelamin'];
            $lahir = $r2['lahir'];
            $alamat = $r2['alamat']; }
          ?>
            <tr>
                <th scope="row"> <?php echo $nama ?> </th>
           <th scope="row"> <?php echo $jurusan ?> </th>
           <th scope="row"> <?php echo $email ?> </th>
           <th scope="row"> <?php echo $password ?> </th>
           <th scope="row"> <?php echo $jeniskelamin ?> </th>
           <th scope="row"> <?php echo $lahir ?> </th>
           <th scope="row"> <?php echo $alamat ?> </th>
          
            </tr>

</tbody>

 </table>


 </body>

</html>